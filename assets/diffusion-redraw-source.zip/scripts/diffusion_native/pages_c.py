"""Native PowerPoint redraws of Diffusion-DPO and Attend-and-Excite."""


def draw7(g):
    """Diffusion-DPO preference training overview."""
    # Two-step workflow panels.
    g.panel(10, 159, 404, 381, tone='gray', name='Base diffusion training')
    g.panel(425, 159, 864, 381, tone='blue', name='Diffusion-DPO optimization')
    g.text(26, 171, 372, 35, 'Step1: Train Base Diffusion Model', size=25, italic=True, font='Times New Roman')
    g.text(535, 171, 645, 35, 'Step2: Optimize Diffusion Model via Diffusion-DPO', size=25, italic=True, font='Times New Roman')

    # Prompt card and its image examples.
    g.box(52, 238, 119, 244, tone='gray', name='Prompt-image examples', radius=True)
    g.text(64, 246, 95, 49, '“A castle\non a hill”', size=20, bold=True)
    g.text(89, 296, 44, 20, '•••', size=21, bold=True)
    g.art(64, 318, 96, 68, 'castle', variant=0, name='Castle prompt example')
    g.art(64, 396, 96, 58, 'mountains', name='Landscape prompt example')
    g.text(89, 456, 44, 20, '•••', size=21, bold=True)
    g.text(31, 490, 166, 30, 'Prompt-Image Data', size=21, font='Arial')

    # Base model.
    g.arrow([(174, 367), (237, 367)], tone='arrow', width=3.1, name='Prompt data to base model')
    g.bars(240, 307, 148, 120, n=4, tone='green', name='Base diffusion model')
    g.text(229, 436, 166, 25, r'Diffusion Model $\epsilon_\theta$', size=20, font='Arial', name='Base diffusion model label')

    # Preference data: the preferred and less-preferred castle samples.
    g.art(446, 331, 76, 78, 'castle', variant=0, frame='line', name='Preferred castle sample y_w')
    g.eq(525, 351, 32, 40, r'>', size=32, name='Preference ranking sign')
    g.art(560, 331, 77, 78, 'castle', variant=1, frame='line', name='Less preferred castle sample y_l')
    g.eq(461, 423, 51, 33, r'y_w', size=24, name='Preferred sample label')
    g.eq(578, 423, 50, 33, r'y_l', size=24, name='Less preferred sample label')
    g.text(464, 457, 164, 32, 'Preference Data', size=21, font='Arial', name='Preference Data')
    g.art(508, 254, 64, 63, 'people', name='Preference annotators')

    # Inputs feed trainable and frozen copies in parallel.
    # c and x_t join at the split; preferred/unpreferred examples also condition both networks.
    g.eq(661, 240, 40, 31, r'c', size=25, name='Condition c')
    g.eq(658, 274, 45, 31, r'x_t', size=24, name='Noisy latent x_t')
    g.arrow([(638, 370), (668, 370), (668, 303), (727, 303)], tone='arrow', width=2.8, head=False, radius=5, name='Preference data into shared condition bus')
    g.arrow([(697, 290), (727, 290)], tone='arrow', width=2.8, name='Noisy latent into shared condition bus')
    g.arrow([(697, 253), (727, 253), (727, 290)], tone='arrow', width=2.5, head=False, radius=5, name='Prompt condition to shared condition bus')
    g.arrow([(727, 253), (782, 253)], tone='arrow', width=2.8, name='Trainable model input')
    g.arrow([(727, 434), (782, 434)], tone='arrow', width=2.8, name='Frozen model input')
    g.arrow([(727, 253), (727, 434)], tone='arrow', width=2.2, head=False, name='Shared condition trunk')
    g.bars(782, 233, 135, 98, n=4, tone='green', name='Trainable diffusion model')
    g.text(765, 337, 175, 25, r'Diffusion Model $\epsilon_\theta$', size=20, font='Arial', name='Trainable diffusion model label')
    g.bars(782, 381, 135, 95, n=4, tone='green', name='Frozen reference model')
    g.text(770, 479, 165, 24, 'Frozen Reference', size=20, font='Arial', name='Frozen reference label')
    g.text(795, 503, 120, 24, r'Model $\epsilon_{ref}$', size=20, font='Arial', name='Frozen reference model label')

    # DPO objective and feedback arrows; dashed likelihood path is from frozen reference.
    g.box(1038, 322, 231, 63, tone='blue', name='DPO loss container', radius=True)
    g.eq(1040, 332, 225, 43, r'L_{D-DPO}(c,y_w,y_l)', size=25, name='DPO objective')
    g.arrow([(917, 432), (1159, 432), (1159, 385)], tone='blue', width=2.3, dash=True, name='Reference likelihood to DPO objective')
    g.arrow([(917, 297),(972,297),(972,348),(1038,348)],tone='arrow',width=2.3,radius=5,name='Trainable denoising prediction to DPO objective')
    g.text(1014,251,135,24,'weight update',size=16,italic=True,name='Direction of gradient update')
    g.arrow([(1159, 322), (1159, 280), (917, 280)], tone='arrow', width=3.0, radius=5, name='DPO loss feedback to trainable model')
    g.text(1037, 439, 235, 51, 'preference alignment\nover denoising likelihood', size=19, italic=True, name='Preference alignment annotation')
    g.text(505, 568, 297, 36, '(a) Diffusion-DPO', size=36, bold=True, name='Figure caption')


def draw8(g):
    """Attend-and-Excite training-free latent refinement overview."""
    # Three workflow panels.
    g.panel(10, 99, 290, 493, tone='gray', name='Prompt denoising')
    g.panel(310, 99, 620, 493, tone='blue', name='Attend-and-Excite refinement')
    g.panel(941, 99, 349, 493, tone='blue', name='Continue denoising')
    g.text(43, 108, 224, 57, 'Step1: Denoise with\nText Prompt', size=25, italic=True, font='Times New Roman')
    g.text(352, 108, 535, 39, 'Step2: Attend-and-Excite Latent Refinement', size=25, italic=True, font='Times New Roman')
    g.text(964, 108, 302, 57, 'Step 3: Continue\nDenoising to Final Image', size=25, italic=True, font='Times New Roman')

    # Step 1: prompt, tokenization, cross attention, and noisy latent.
    g.box(49, 189, 230, 43, tone='blue', name='Text prompt', radius=True)
    g.text(57, 194, 214, 32, '“a cat and a dog”', size=23, bold=True, name='Text prompt content')
    g.arrow([(164, 232), (164, 264)], tone='arrow', width=2.8, name='Prompt to tokens')
    tokens=[(29, '[a]', 38), (70, '[cat]', 53), (130, '[and]', 49), (184, '[a]', 38), (229, '[dog]', 53)]
    for i,(x,label,w) in enumerate(tokens):
        g.box(x, 266, w, 31, tone='green' if label in ('[cat]','[dog]') else 'gray', name='Token '+label, radius=True)
        g.text(x+2, 269, w-4, 25, label, size=20, name='Token text '+str(i+1))
    # Subject-token grouping bracket and attention flow.
    g.arrow([(96, 315), (96, 329), (260, 329), (260, 315)], tone='arrow', width=2.1, head=False, name='Subject-token U bracket')
    g.arrow([(96, 315), (96, 298)], tone='arrow', width=2.0, name='Subject token highlight left')
    g.arrow([(260, 315), (260, 298)], tone='arrow', width=2.0, name='Subject token highlight right')
    g.text(106, 330, 145, 22, 'Subject Tokens', size=19, name='Subject Tokens')
    g.arrow([(200, 352), (200, 382)], tone='arrow', width=2.8, name='Tokens to cross attention')
    g.box(127, 387, 148, 32, tone='blue', name='Cross-attention block', radius=True)
    g.text(131, 391, 140, 25, 'Cross-Attention', size=19, name='Cross-attention label')
    g.art(28, 449, 67, 67, 'noise', name='Noisy latent')
    g.text(24, 524, 76, 47, 'Noisy\nLatent $z_t$', size=19, name='Noisy latent label')
    g.bars(133, 444, 139, 80, n=4, tone='green', name='Diffusion U-Net')
    g.text(131, 530, 142, 48, 'Diffusion U-Net\n(Denoising Model)', size=18, name='Denoising model label')
    g.arrow([(95, 482), (133, 482)], tone='arrow', width=2.8, name='Noisy latent into U-Net')
    g.arrow([(165, 419), (165, 444)], tone='arrow', width=2.8, name='Cross attention into U-Net left')
    g.arrow([(237, 419), (237, 444)], tone='arrow', width=2.8, name='Cross attention into U-Net right')

    # Step 2: model attention maps feed a token-selection objective, then update z_t.
    g.box(370, 233, 151, 34, tone='blue', name='Cross-attention block', radius=True)
    g.text(375, 237, 141, 26, 'Cross-Attention', size=19, name='Cross-attention label')
    g.arrow([(412, 267), (412, 302)], tone='arrow', width=2.3, name='Cross attention to U-Net left')
    g.arrow([(478, 267), (478, 302)], tone='arrow', width=2.3, name='Cross attention to U-Net right')
    g.eq(307, 334, 41, 31, r'z_t', size=22, name='Input latent to refinement')
    g.arrow([(344, 351), (376, 351)], tone='arrow', width=2.8, name='Latent into refinement U-Net')
    g.bars(376, 302, 139, 97, n=4, tone='green', name='Denoising U-Net')
    g.text(370, 405, 151, 46, 'Denoising Model\n(Diffusion U-Net)', size=19, name='Refinement model label')

    # Heatmaps are separate subject attention maps. Model output branches to each map and selection.
    g.arrow([(515, 351), (538, 351), (538, 268), (567, 268)], tone='arrow', width=2.7, radius=5, name='Model output to cat attention map')
    g.arrow([(538, 351), (538, 400), (567, 400)], tone='arrow', width=2.7, radius=5, name='Model output to dog attention map')
    g.art(567, 228, 80, 81, 'heatcat', name='Cat attention heatmap')
    g.art(567, 360, 80, 81, 'heatdog', name='Dog attention heatmap')
    g.eq(565, 198, 85, 27, r'A_t(cat)', size=22, name='Cat attention label')
    g.eq(565, 329, 87, 27, r'A_t(dog)', size=22, name='Dog attention label')
    g.arrow([(647, 268), (670, 268), (670, 324)], tone='arrow', width=2.5, head=False, name='Cat map to shared selection junction')
    g.arrow([(647, 400), (670, 400), (670, 324)], tone='arrow', width=2.5, head=False, name='Dog map to shared selection junction')
    g.arrow([(670,324),(679,324),(679,255),(688,255)], tone='arrow', width=2.4,radius=4, name='Attention maps to neglected subject token')

    # Selection criterion and update rule as native editable math.
    g.box(688, 227, 232, 56, tone='blue', name='Neglected-token criterion', radius=True)
    g.eq(695, 231, 218, 48, r'j^* = \underset{i}{\operatorname{argmin}}\,\max A_t(c_i)', size=20, name='Neglected-token selection equation')
    g.text(735, 286, 150, 44, 'Most neglected\nsubject token', size=18, name='Most neglected subject token')
    g.arrow([(808, 332), (808, 379)], tone='arrow', width=2.8, name='Selected token to latent update')
    g.box(688, 379, 232, 57, tone='blue', name='Latent update rule', radius=True)
    g.eq(694, 385, 220, 46, r'z_t \leftarrow z_t + \eta \nabla_{z_t}\,\max A_t(c_{j^*})', size=21, name='Attention latent update equation')
    g.text(706, 440, 196, 29, 'Increase token attention', size=18, name='Increase token attention')

    # Return loop: update latent goes back into the denoising U-Net over chosen steps.
    g.box(500, 499, 249, 43, tone='blue', name='Attend-and-Excite loop label', radius=True)
    g.text(507, 503, 235, 34, 'Attend-and-Excite', size=23, bold=True, name='Attend-and-Excite label')
    g.arrow([(908,436),(908,471),(876,471),(876,517),(749,517)], tone='arrow', width=3.2, head=False, radius=14, name='Attention update return path')
    g.arrow([(500, 517), (336, 517), (336, 360)], tone='arrow', width=3.2, head=True, radius=14, name='Updated latent back to input latent')
    g.text(461, 548, 351, 31, 'Repeat for selected denoising steps', size=20, italic=True, name='Repeat for selected denoising steps')

    # Step 3: refined latent, continued denoising, final image.
    g.text(954, 257, 58, 42, 'Refined\nLatent', size=18, name='Refined latent label')
    g.art(954, 322, 58, 60, 'noise', name='Refined latent representation')
    g.eq(958, 385, 49, 29, r'z_t', size=20, name='Refined latent z_t')
    g.arrow([(920,403),(936,403),(936,351),(954,351)],tone='arrow',radius=5,width=2.3,name='Refinement produces the latent for continued denoising')
    g.arrow([(1014, 350), (1041, 350)], tone='arrow', width=2.8, name='Refined latent to denoising model')
    g.brace(1041, 295, 98, -17, tone='arrow', name='Continue denoising brace')
    g.text(1041, 218, 97, 48, 'Continue\nDenoising', size=19, name='Continue denoising label')
    g.bars(1041, 306, 98, 95, n=4, tone='green', name='Final denoising model')
    g.text(1043, 407, 97, 48, 'Denoising\nModel', size=19, name='Final denoising model label')
    g.arrow([(1139, 350), (1174, 350)], tone='arrow', width=2.8, name='Denoised latent to final image')
    g.text(1198, 240, 75, 56, 'Final\nImage', size=19, name='Final image label')
    g.art(1175, 300, 111, 111, 'catdog', name='Final cat and dog image')
    g.box(962, 478, 312, 70, tone='blue', name='Subject fidelity outcome', radius=True)
    g.text(973, 485, 290, 56, 'All subject tokens are expressed\n(Improved subject fidelity)', size=20, italic=True, name='Subject fidelity outcome label')

    # Figure title/subtitle.
    g.text(465, 628, 366, 37, 'Attend-and-Excite', size=42, bold=True, name='Figure title')
    g.text(268, 679, 766, 29, 'Training-free semantic guidance via cross-attention control', size=27, bold=True, name='Figure subtitle')
