"""Editable semantic redraws for DreamBooth, PhotoMaker, and StoryDiffusion."""


def _t(g, x, y, w, h, text, size=18, bold=False, italic=False, align="center", color="ink", name=None, font="Times New Roman"):
    g.text(x, y, w, h, text, size=size, bold=bold, italic=italic, align=align, color=color, name=name, font=font)


def _prompt(g, x, y, w, h, lines, name, tone="blue", accent=None):
    g.box(x, y, w, h, tone=tone, name=name, radius=True)
    n=len(lines)
    line_h=22
    top=y+(h-n*line_h)/2
    for j,line in enumerate(lines):
        if accent and j in accent:
            pre,mark,post=accent[j]
            g.text(x+5,top+j*line_h,w-10,line_h,pre+r'$s^*$'+post,size=21,
                   math_color='#773390',name=name+' • unique identifier')
        else:
            _t(g,x+5,top+j*line_h,w-10,line_h,line,size=20)


def draw4(g):
    """DreamBooth: method overview and personalized inference."""
    g.panel(6,22,386,306,tone="gray",name="DreamBooth step 1 data preparation")
    g.panel(396,22,490,306,tone="blue",name="DreamBooth step 2 fine tuning")
    g.panel(895,22,399,306,tone="blue",name="DreamBooth step 3 prior objective")
    g.panel(7,391,1287,237,tone="blue",name="DreamBooth personalized inference")
    _t(g,35,28,320,32,"Step1: Data Preparation",28,italic=True)
    _t(g,407,28,470,32,"Step2: Fine-Tune Diffusion Model",28,italic=True)
    _t(g,919,28,351,31,"Step3: Optimize with",27,italic=True)
    _t(g,921,53,350,31,"Subject and Class Priors",27,italic=True)

    # Training reference images and subject prompt.
    for i,(x,y) in enumerate([(25,90),(110,90),(25,167),(110,167)]):
        g.art(x,y,84,75,"corgi",variant=i,frame="none",name=f"DreamBooth reference subject {i+1}")
    _t(g,25,269,169,23,"A few (3–5) images",16)
    _t(g,45,291,130,23,"of a subject",16)
    _t(g,113,236,40,25,"…",22,bold=True)
    _prompt(g,238,135,138,82,["“a photo of","s* dog”"],"DreamBooth subject prompt",accent={1:("","s*"," dog”")})
    g.arrow([(195,176),(232,176)],tone="arrow",width=2.8)
    _t(g,228,260,155,23,"Subject prompt",16)
    g.text(198,283,183,23,"(with a unique token $s^*$)",size=15,math_color="#773390",name="Unique subject identifier note")

    # Fine tuning U-Net gets instance and class prompts.
    _prompt(g,414,102,144,73,["“a photo of","s* dog”"],"DreamBooth instance training prompt",accent={1:("","s*"," dog”")})
    _prompt(g,414,196,145,73,["“a photo of","a dog”"],"DreamBooth class training prompt")
    g.arrow([(560,139),(601,139)],tone="arrow",width=2.8)
    g.arrow([(560,233),(601,233)],tone="arrow",width=2.8)
    g.box(601,105,269,197,'green',name='DreamBooth network enclosure')
    g.unet(601,112,269,150,tone="green",name="DreamBooth feature blocks",outer=False)
    g.box(654,80,161,36,tone="blue",name="DreamBooth name badge",radius=True)
    _t(g,654,82,161,31,"DreamBooth",27,bold=True)
    _t(g,646,244,177,25,"Denoising U-Net",20)
    g.eq(713,268,48,25,r'(\theta)',size=21)
    g.arrow([(870,187),(922,187)],tone="arrow",width=2.8)

    # Subject preservation and class-prior regularization objective.
    g.box(925,107,354,184,tone="blue",name="DreamBooth loss panel",radius=True)
    g.eq(968,114,265,36,r"\mathcal{L}=\mathcal{L}_{\mathrm{sub}}+\lambda\mathcal{L}_{\mathrm{prior}}",size=23,name="DreamBooth total loss")
    g.curve([(958,175),(946,175),(953,204),(949,210),(947,214),(946,214),(942,214),(947,215),(949,216),(950,221),(952,231),(945,251),(958,252)],tone='ink',width=1.7,name='Subject and class prior brace')
    g.eq(963,166,80,32,r"\mathcal{L}_{\mathrm{sub}}:",size=21,name="Subject loss term")
    _t(g,1038,165,222,25,"preserve the subject",18)
    g.text(1038,188,230,26,"“$s^*$” (personalization)",size=17,math_color="#773390",name="Personalized subject term")
    g.eq(963,221,80,33,r"\mathcal{L}_{\mathrm{prior}}:",size=20,name="Prior loss term")
    _t(g,1038,218,222,25,"retain the class prior",18)
    _t(g,1034,241,238,27,"(e.g., general “dog” concept)",16)

    # Inference branch, tuned U-Net, and generated outputs.
    _t(g,46,397,408,31,"Inference: Personalized Generation",27,italic=True,align="left")
    _prompt(g,59,439,210,62,["“a s* dog","in the snow”"],"Snow scene inference prompt",accent={0:("“a ","s*"," dog")})
    _prompt(g,49,516,222,66,["“a s* dog","wearing sunglasses”"],"Sunglasses inference prompt",accent={0:("“a ","s*"," dog")})
    _t(g,143,587,39,22,"…",21,bold=True)
    g.arrow([(274,464),(301,464),(301,520)],head=False)
    g.arrow([(274,558),(301,558),(301,520)],head=False)
    g.arrow([(301,520),(349,520)])
    g.box(350,440,282,163,'green',name='Fine-tuned DreamBooth enclosure')
    with g.group('Fine-tuned U-Net feature hierarchy'):
        for i,(x,top,bottom) in enumerate([(363,462,588),(397,484,582),(427,532,574),(455,546,570),
                                            (492,549,568),(525,541,570),(555,515,577),(589,469,588)]):
            bw=22 if i not in (3,4,5) else 19
            d=7 if i<4 else -7
            g.poly([(x,top),(x+bw,top+d),(x+bw,bottom-d/2),(x,bottom)],
                   '#E2EFCF','#78A455',1.5,f'Fine-tuned U-Net level {i+1}')
    g.snow(388,447,26)
    _t(g,421,462,147,27,"Fine-Tuned",20)
    _t(g,412,487,161,26,"Diffusion Model",20)
    g.eq(466,513,59,25,r'(\theta^*)',size=20)
    g.arrow([(633,520),(690,520)],tone="arrow",width=2.8)
    for i,(x,variant) in enumerate([(690,4),(875,5),(1055,6)]):
        g.art(x,443,174,158,"corgi",variant=variant,frame="none",name=f"DreamBooth generated corgi context {i+1}")
    _t(g,1233,498,54,35,"…",26,bold=True)
    _t(g,350,333,600,34,"(a) DreamBooth Training (Method Overview)",30,bold=True)
    _t(g,200,632,925,34,"(b) Inference: Generate Images of the Learned Subject in New Contexts",28,bold=True)
    g.rect(8,686,1285,49,"#EAE7F0",stroke=None,width=0,radius=14,name="DreamBooth title banner")
    _t(g,66,686,1168,47,"DreamBooth: Subject-Driven Personalized Text-to-Image Generation",35,bold=True)


def draw5(g):
    """PhotoMaker: multi-image ID embeddings and identity-preserving generation."""
    g.panel(7,157,454,427,tone="gray",name="PhotoMaker step 1 inputs")
    g.panel(467,157,444,427,tone="blue",name="PhotoMaker step 2 stacked ID embedding")
    g.panel(915,157,378,427,tone="blue",name="PhotoMaker step 3 personalized generation")
    _t(g,26,168,205,30,"Step 1: Inputs",22,italic=True)
    _t(g,482,168,390,30,"Step 2: Stacked ID Embedding",22,italic=True)
    _t(g,919,168,358,30,"Step 3: Personalized Generation",22,italic=True)

    # Multiple ID image inputs and image encoder path.
    for i,x in enumerate((19,97,168)):
        g.art(x,251,69,98,"portrait",variant=i,frame="none",name=f"PhotoMaker identity reference {i+1}")
    g.brace(26,353,203,13,name="Multiple ID images brace")
    _t(g,42,369,182,24,"Multiple ID Images",17,italic=True)
    g.bars(263,251,85,88,n=4,tone="green",name="PhotoMaker ID image encoder")
    g.arrow([(235,294),(263,294)],tone="arrow",width=2.5)
    _t(g,260,345,92,24,"ID Image",17)
    _t(g,275,367,67,22,"Encoder",17)
    g.arrow([(348,294),(373,294)],tone="arrow",width=2.5)
    g.box(375,252,72,23,tone="blue",name="PhotoMaker image embedding one",radius=True)
    g.box(375,282,72,22,tone="green",name="PhotoMaker image embedding two",radius=True)
    g.box(375,312,72,23,tone="purple",name="PhotoMaker image embedding three",radius=True)
    _t(g,383,203,71,24,"Image",18,italic=True)
    _t(g,355,224,102,24,"Embeddings",18,italic=True)
    _t(g,405,341,43,20,"…",21)

    # Text prompt and frozen text encoder path.
    g.box(22,458,180,66,tone="blue",name="PhotoMaker text prompt")
    rich=g.text(26,466,172,24,"“a woman img",size=20,italic=True,name="PhotoMaker subject and trigger word")
    first=rich.text_frame.paragraphs[0].runs[0]
    first.text="“a "
    accent=rich.text_frame.paragraphs[0].add_run()
    accent.text="woman img"
    from copy import deepcopy
    accent._r.insert(0,deepcopy(first._r.rPr))
    from pptx.dml.color import RGBColor
    accent.font.bold=True
    accent.font.color.rgb=RGBColor.from_string("294EB4")
    _t(g,26,491,172,24,"wearing a blue hat”",20,italic=True)
    _t(g,55,528,123,27,"Text Prompt",19)
    g.arrow([(202,490),(230,490)],tone="arrow",width=2.5)
    g.bars(233,446,88,84,n=4,tone="blue",name="Frozen text encoder")
    _t(g,258,532,72,22,"Frozen",17)
    _t(g,246,553,92,22,"Text Encoder",17)
    g.snow(309,439,25,name="Frozen text encoder snowflake")
    g.arrow([(321,489),(343,489)],tone="arrow",width=2.5)
    g.box(352,470,23,39,tone="purple",name="PhotoMaker class token",radius=True)
    g.box(379,470,22,39,tone="blue",name="PhotoMaker text token 1",radius=True)
    g.box(406,470,22,39,tone="blue",name="PhotoMaker text token 2",radius=True)
    _t(g,381,415,70,22,"Text",18,italic=True)
    _t(g,354,435,105,22,"Embeddings",18,italic=True)
    g.arrow([(364,530),(364,513)],tone="ink",width=1.7,head=True)
    _t(g,330,535,101,23,"Class Token",16,bold=True,italic=True)
    _t(g,428,469,24,38,"…",20)
    g.arrow([(447,294),(500,294),(500,335)],tone="arrow",width=2.5)
    g.arrow([(454,489),(500,489),(500,400)],tone="arrow",width=2.5)
    g.box(481,335,78,65,tone="blue",name="MLP Fusion",radius=True)
    _t(g,488,341,64,24,"MLP",17,bold=True)
    _t(g,488,365,64,24,"Fusion",17,bold=True)

    # Stacked identity tokens, the concatenation expression, and prompt tokens.
    _t(g,577,278,119,26,"Stacked ID",18,italic=True)
    _t(g,588,300,97,25,"Embedding",18,italic=True)
    g.arrow([(559,367),(582,367)],tone="arrow",width=2.5)
    for i,(x,tone) in enumerate([(592,"green"),(615,"blue"),(638,"green"),(661,"blue")]):
        g.box(x,348,18,37,tone=tone,name=f"Stacked ID embedding token {i+1}",radius=True)
    _t(g,678,350,39,34,"…",22)
    g.box(534,405,201,47,tone="blue",name="PhotoMaker stacked embedding formula border",radius=True)
    g.eq(535,405,201,47,r"s^*=\operatorname{Concat}\,(\hat e_1,\,\ldots,\,\hat e_n)",size=18,name="PhotoMaker stacked embedding formula")
    g.arrow([(719,367),(742,367)],tone="arrow",width=2.5)
    _t(g,770,278,105,26,"Updated",18,italic=True)
    _t(g,741,300,144,26,"Text Embeddings",18,italic=True)
    for i,(x,tone) in enumerate([(746,"green"),(769,"blue"),(792,"blue"),(815,"blue"),(838,"blue"),(861,"blue")]):
        g.box(x,348,18,37,tone=tone,name=f"Updated text embedding token {i+1}",radius=True)
    _t(g,876,350,24,34,"…",21)
    _t(g,776,416,30,22,"$s^*$",17,italic=True)
    _t(g,827,410,58,23,"Other",17,italic=True)
    _t(g,804,431,101,23,"Text Tokens",17,italic=True)
    g.brace(745,394,76,15,name="Identity token group brace")
    g.brace(826,394,61,15,name="Other token group brace")
    g.arrow([(904,367),(932,367)],tone="arrow",width=2.5)

    # SDXL generation and output portraits.
    g.bars(932,309,103,101,n=4,tone="green",name="SDXL diffusion U-Net")
    _t(g,951,430,66,23,"SDXL",17)
    _t(g,919,451,130,24,"Diffusion U-Net",17)
    g.arrow([(1037,359),(1057,359)],tone="arrow",width=2.5)
    g.art(1057,253,113,184,"portrait",variant=3,frame="none",name="PhotoMaker blue hat result 1")
    g.art(1173,253,113,184,"portrait",variant=4,frame="none",name="PhotoMaker blue hat result 2")
    g.brace(1066,445,210,14,name="Identity preserving results brace")
    _t(g,1080,463,190,25,"Identity-Preserving",17,italic=True)
    _t(g,1134,484,91,25,"Results",17,italic=True)
    _t(g,207,605,899,42,"(a) PhotoMaker: Identity-Preserving Personalized Generation",33,bold=True)


def draw6(g):
    """StoryDiffusion: consistent keyframes and long-range video generation."""
    g.panel(7,41,318,300,tone="gray",name="StoryDiffusion step 1 story prompts")
    g.panel(339,41,483,300,tone="blue",name="StoryDiffusion step 2 self attention")
    g.panel(836,41,457,300,tone="blue",name="StoryDiffusion consistent keyframes")
    g.panel(8,439,226,234,tone="gray",name="StoryDiffusion keyframe conditions")
    g.panel(243,439,466,234,tone="blue",name="StoryDiffusion semantic motion predictor")
    g.panel(718,439,575,234,tone="blue",name="StoryDiffusion transition video diffusion")
    _t(g,42,47,270,30,"Step 1: Story Prompts",22,italic=True)
    _t(g,384,47,386,30,"Step 2: Consistent Self-Attention",22,italic=True)
    _t(g,915,47,300,30,"Consistent Keyframes",22,italic=True)

    # Story prompt document and three editable prompt cards.
    g.art(50,142,95,114,"paper",variant=0,frame="none",name="Story prompt document icon")
    g.arrow([(145,199),(205,199)],tone="arrow",width=2.7)
    for i,y in enumerate((119,178,237)):
        g.box(212,y,81,42,tone="blue",name=f"Story prompt card {i+1}",radius=True)
        _t(g,212,y+2,81,36,f"$p_{i+1}$",23,italic=True)
    _t(g,91,289,161,25,"Text Prompts",18,font="Arial")

    # Shared token grids feed consistent self-attention in the diffusion U-Net.
    for i,y in enumerate((105,176,247)):
        g.art(369,y,62,53,"grid",variant=i,frame="none",name=f"Shared token grid {i+1}")
    g.box(493,106,299,172,tone="green",name="Consistent self-attention U-Net")
    g.bars(510,148,69,114,2,'green','Left feature banks',outer=False)
    g.bars(705,148,69,114,2,'green','Right feature banks',outer=False)
    _t(g,543,109,198,29,"Diffusion U-Net",19,bold=True)
    g.box(606,175,90,61,tone="blue",name="Consistent self-attention CSA",radius=True)
    _t(g,606,179,90,54,"CSA",24,bold=True)
    for y,destination in ((132,183),(205,205),(272,228)):
        g.arrow([(433,y),(469,y),(469,destination),(606,destination)],tone="arrow",width=2.6)
    _t(g,402,298,250,25,"Shared tokens across images",19,font="Arial")
    g.arrow([(665,295),(665,324)],tone="ink",width=1.3,head=False,name="Shared tokens divider")
    _t(g,682,296,113,23,"Training-free",18,font="Arial")
    g.arrow([(795,198),(854,198)],tone="arrow",width=2.7)

    # Consistent keyframes.
    for i,x in enumerate((854,962,1069,1175)):
        g.art(x,119,103,140,"anime",variant=i,frame="line",name=f"Consistent keyframe {i+1}")
    _t(g,916,289,275,24,"Identity & appearance preserved",18,font="Arial")

    # Keyframes route to the frame-wise semantic motion representation.
    g.arrow([(1155,341),(1155,401),(106,401),(106,501)],tone="arrow",width=4.4,head=True,radius=11,name="Keyframe transfer to video generation")
    g.art(28,501,91,122,"anime",variant=0,frame="line",name="Video keyframe condition 1")
    g.art(130,501,87,122,"anime",variant=3,frame="line",name="Video keyframe condition 2")
    _t(g,30,628,185,25,"Keyframe Conditions",17,font="Arial")
    g.arrow([(219,563),(269,563)],tone="arrow",width=2.7)
    g.box(270,531,91,72,tone="blue",name="StoryDiffusion image encoder",radius=True)
    _t(g,281,539,69,28,"Image",17,bold=True)
    _t(g,280,565,71,27,"Encoder",17,bold=True)
    g.arrow([(361,567),(388,567)],tone="arrow",width=2.7)
    g.box(388,507,178,115,tone="green",name="Semantic motion predictor",radius=True)
    g.bars(397,517,37,95,2,"green","Semantic predictor left feature bank",outer=False)
    g.bars(518,517,39,95,2,"green","Semantic predictor right feature bank",outer=False)
    _t(g,434,526,84,24,"Semantic",16,bold=True)
    _t(g,434,550,84,23,"Motion",16,bold=True)
    _t(g,434,573,84,25,"Predictor",16,bold=True)
    g.arrow([(567,567),(599,567)],tone="arrow",width=2.7)
    for i,x in enumerate((599,622,645,668,691)):
        g.box(x,537,17,58,tone="blue",name=f"Frame-wise motion embedding {i+1}",radius=True)
    _t(g,572,608,119,24,"Frame-wise",17,font="Arial")
    _t(g,548,630,152,24,"motion embeddings",17,font="Arial")

    # Transition video diffusion and editable filmstrip.
    g.bars(749,520,164,104,n=4,tone="green",name="Transition video diffusion model")
    g.arrow([(707,567),(730,567),(730,483),(883,483)],tone="arrow",width=2.8,head=False,name="Motion embedding conditioning trunk")
    for i,x in enumerate((769,798,826,855,883)):
        g.arrow([(x,483),(x,520)],tone="arrow",width=2.2,head=True,name=f"Motion conditioning arrow {i+1}")
    g.arrow([(914,567),(946,567)],tone="arrow",width=2.7)
    g.art(946,509,337,117,"anime",variant=4,frame="filmstrip",name="Smooth consistent generated video filmstrip")
    _t(g,708,627,216,24,"Video Diffusion Model",17,font="Arial")
    _t(g,995,627,231,24,"Smooth Consistent Video",17,font="Arial")

    _t(g,385,348,533,39,"(a) Consistent Image Generation",33,bold=True)
    _t(g,275,439,390,29,"Step 3: Semantic Motion Predictor",22,italic=True)
    _t(g,807,439,424,29,"Step 4: Transition Video Diffusion",22,italic=True)
    _t(g,392,672,516,42,"(b) Long-Range Video Generation",33,bold=True)
