#!/usr/bin/env python3
"""Prepare/check a minimal native PowerPoint editability probe for Diffusion-DPO."""
from __future__ import annotations

import argparse
import json
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SOURCE = ROOT / 'docs/public_results/diffusion_native_redraw/Single_Figure_PPTX/07_Diffusion-DPO.pptx'
DEFAULT_TMP = Path(__file__).resolve().parent / '.edit_probe_tmp'
SLIDE_XML = 'ppt/slides/slide1.xml'
PRESENTATION_XML = 'ppt/presentation.xml'
SOURCE_W = 1300
SOURCE_H = 743
EMU_PER_SLIDE_PIXEL = 6350

P_NS = 'http://schemas.openxmlformats.org/presentationml/2006/main'
A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main'
M_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
NS = {'p': P_NS, 'a': A_NS, 'm': M_NS}
ET.register_namespace('p', P_NS)
ET.register_namespace('a', A_NS)
ET.register_namespace('m', M_NS)


def tag(ns: str, name: str) -> str:
    return f'{{{ns}}}{name}'


def shape_name(shape: ET.Element) -> str | None:
    if shape.tag == tag(P_NS, 'grpSp'):
        node = shape.find('./p:nvGrpSpPr/p:cNvPr', NS)
    elif shape.tag == tag(P_NS, 'sp'):
        node = shape.find('./p:nvSpPr/p:cNvPr', NS)
    else:
        return None
    return node.get('name') if node is not None else None


def one_named(root: ET.Element, name: str, kind: str) -> ET.Element:
    matches = [e for e in root.iter() if e.tag == tag(P_NS, kind) and shape_name(e) == name]
    if len(matches) != 1:
        raise RuntimeError(f'expected one {kind} named {name!r}; found {len(matches)}')
    return matches[0]


def _read_xml(zf: zipfile.ZipFile, name: str) -> ET.Element:
    try:
        return ET.fromstring(zf.read(name))
    except KeyError as exc:
        raise RuntimeError(f'PPTX is missing {name}') from exc


def prepare(source: Path, destination: Path) -> Path:
    """Edit native text, native OMML, and the grouped preferred sample in a copy."""
    source = source.expanduser().resolve()
    destination = destination.expanduser().resolve()
    if source == destination:
        raise RuntimeError('output must be a copy; refusing to modify the source PPTX')
    destination.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(source, 'r') as zin:
        slide = _read_xml(zin, SLIDE_XML)
        presentation = _read_xml(zin, PRESENTATION_XML)
        slide_size = presentation.find('./p:sldSz', NS)
        if slide_size is None:
            raise RuntimeError('presentation.xml has no p:sldSz')
        slide_width_emu = int(slide_size.get('cx'))
        # The group uses slide EMUs; convert the requested 8 source pixels to slide EMUs.
        dx_emu = round(8 * slide_width_emu / SOURCE_W)

        pref = one_named(slide, 'Preference Data', 'sp')
        pref_runs = pref.findall('.//a:t', NS)
        if len(pref_runs) != 1 or pref_runs[0].text != 'Preference Data':
            raise RuntimeError('Preference Data native text shape did not match expected content')
        pref_runs[0].text = 'Edited label'

        sample_label = one_named(slide, 'Preferred sample label', 'sp')
        subscripts = sample_label.findall('.//m:sSub', NS)
        if len(subscripts) != 1:
            raise RuntimeError(f'Preferred sample label must contain one OMML subscript; found {len(subscripts)}')
        sub_parts = subscripts[0].findall('./m:sub//m:t', NS)
        if len(sub_parts) != 1 or sub_parts[0].text != 'w':
            raise RuntimeError('Preferred sample label OMML did not contain the expected subscript w')
        sub_parts[0].text = 'q'

        preferred_art = one_named(slide, 'Preferred castle sample y_w', 'grpSp')
        xfrm = preferred_art.find('./p:grpSpPr/a:xfrm', NS)
        off = xfrm.find('./a:off', NS) if xfrm is not None else None
        if off is None or off.get('x') is None:
            raise RuntimeError('preferred castle group has no x offset')
        off.set('x', str(int(off.get('x')) + dx_emu))

        slide_bytes = ET.tostring(slide, encoding='UTF-8', xml_declaration=True, short_empty_elements=True)
        with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
            for item in zin.infolist():
                data = slide_bytes if item.filename == SLIDE_XML else zin.read(item.filename)
                zout.writestr(item, data)
    return destination


def _pixmap(page, fitz, zoom: float = 2.0):
    import numpy as np
    pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
    return np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)[:, :, :3].copy()


def _pixel_box(page, source_box: tuple[float, float, float, float], zoom: float):
    x, y, w, h = source_box
    sx = page.rect.width / SOURCE_W
    sy = page.rect.height / SOURCE_H
    return tuple(round(v) for v in (x*sx*zoom, y*sy*zoom, (x+w)*sx*zoom, (y+h)*sy*zoom))


def _crop(img, box):
    x0, y0, x1, y1 = box
    x0, y0 = max(0, x0), max(0, y0)
    return img[y0:min(img.shape[0], y1), x0:min(img.shape[1], x1)]


def _chars_in_source_region(page, source_box):
    x0, y0, x1, y1 = _pixel_box(page, source_box, 1.0)
    chars = []
    for block in page.get_text('rawdict')['blocks']:
        for line in block.get('lines', []):
            for span in line.get('spans', []):
                for ch in span.get('chars', []):
                    x, y, r, b = ch['bbox']
                    if x0 <= (x+r)/2 <= x1 and y0 <= (y+b)/2 <= y1:
                        chars.append((ch['c'], (x, y, r, b)))
    return chars


def check(edited_pdf: Path, original_pdf: Path) -> dict:
    """Check page-7 text/math changes, preferred-art translation, and edit locality."""
    try:
        import pymupdf as fitz
        import numpy as np
    except ImportError as exc:
        raise RuntimeError('check requires PyMuPDF and NumPy') from exc

    edited_doc = fitz.open(edited_pdf)
    original_doc = fitz.open(original_pdf)
    if len(original_doc) < 7:
        raise RuntimeError(f'original PDF must have at least 7 pages; found {len(original_doc)}')
    ep = edited_doc[0] if len(edited_doc) == 1 else edited_doc[6]
    op = original_doc[6]
    if abs(ep.rect.width-op.rect.width) > 1 or abs(ep.rect.height-op.rect.height) > 1:
        raise RuntimeError(f'page dimensions differ: edited={ep.rect}, original={op.rect}')

    page_text = ep.get_text('text')
    edit_hits = ep.search_for('Edited label')
    if not edit_hits or 'Edited label' not in page_text:
        raise RuntimeError('Edited label was not found in the exported PDF')
    if 'Preference Data' in page_text:
        raise RuntimeError('old Preference Data label is still visible in the exported PDF')

    math_chars = _chars_in_source_region(ep, (455, 414, 530, 461))
    y_boxes = [box for char, box in math_chars if char.lower() == 'y']
    q_boxes = [box for char, box in math_chars if char.lower() == 'q']
    if not y_boxes or not q_boxes:
        raise RuntimeError(f'could not find y and q in the preferred sample OMML region: {math_chars!r}')
    y_box = min(y_boxes, key=lambda b: b[0])
    q_box = min(q_boxes, key=lambda b: b[0])
    if q_box[0] <= y_box[0] or (q_box[1]+q_box[3])/2 <= (y_box[1]+y_box[3])/2:
        raise RuntimeError(f'q was not rendered below and to the right of y: y={y_box}, q={q_box}')

    zoom = 2.0
    before = _pixmap(op, fitz, zoom)
    after = _pixmap(ep, fitz, zoom)
    if before.shape != after.shape:
        raise RuntimeError(f'rendered page dimensions differ: {before.shape} vs {after.shape}')
    diff = np.max(np.abs(before.astype(np.int16)-after.astype(np.int16)), axis=2)
    changed = diff > 10

    pref_box = _pixel_box(op, (455, 445, 200, 60), zoom)
    math_box = _pixel_box(op, (450, 410, 100, 60), zoom)
    old_art_box = _pixel_box(op, (440, 325, 90, 90), zoom)
    new_art_box = _pixel_box(op, (448, 325, 90, 90), zoom)
    label_diff = int(np.count_nonzero(_crop(changed, pref_box)))
    math_diff = int(np.count_nonzero(_crop(changed, math_box)))
    if label_diff < 20:
        raise RuntimeError('Preference Data text region did not physically change')
    if math_diff < 20:
        raise RuntimeError('Preferred sample OMML region did not physically change')

    # A translated crop should match the original artwork at its new position better than at the old one.
    ax0, ay0, ax1, ay1 = old_art_box
    dx = round(8 * op.rect.width / SOURCE_W * zoom)
    art_before = _crop(before, old_art_box)
    art_after_shifted = _crop(after, (ax0+dx, ay0, ax1+dx, ay1))
    art_after_old = _crop(after, old_art_box)
    if art_before.shape != art_after_shifted.shape or art_before.size == 0:
        raise RuntimeError('preferred-art comparison crops do not align')
    aligned_mae = float(np.mean(np.abs(art_before.astype(np.int16)-art_after_shifted.astype(np.int16))))
    old_position_mae = float(np.mean(np.abs(art_before.astype(np.int16)-art_after_old.astype(np.int16))))
    if old_position_mae < 0.8 or aligned_mae >= old_position_mae * 0.85:
        raise RuntimeError(f'preferred art move was not confirmed: shifted MAE={aligned_mae:.3f}, old-position MAE={old_position_mae:.3f}')

    # Only the two requested text areas and the old/new art footprint may change.
    allowed = np.zeros(changed.shape, dtype=bool)
    for box in (pref_box, math_box, old_art_box, new_art_box):
        x0, y0, x1, y1 = box
        x0, y0 = max(0, x0-4), max(0, y0-4)
        x1, y1 = min(allowed.shape[1], x1+4), min(allowed.shape[0], y1+4)
        allowed[y0:y1, x0:x1] = True
    outside = int(np.count_nonzero(changed & ~allowed))
    tolerance = max(150, round(changed.size * 0.00015))
    if outside > tolerance:
        raise RuntimeError(f'content changed outside requested areas: {outside} pixels > {tolerance}')

    return {
        'edited_label_bbox': [float(v) for v in edit_hits[0]],
        'omml_subscript': {'y_bbox': [float(v) for v in y_box], 'q_bbox': [float(v) for v in q_box]},
        'changed_pixels': {'preference_label': label_diff, 'omml_region': math_diff, 'outside_allowed_regions': outside},
        'preferred_art_move': {'source_px': 8, 'aligned_mae': round(aligned_mae, 3), 'old_position_mae': round(old_position_mae, 3)},
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    prep = sub.add_parser('prepare', help='write an edited copy of the single-figure PPTX')
    prep.add_argument('--source', type=Path, default=DEFAULT_SOURCE)
    prep.add_argument('--out', type=Path, default=DEFAULT_TMP/'07_Diffusion-DPO-edited.pptx')
    verify = sub.add_parser('check', help='check an LO-exported probe PDF against the original 8-page PDF')
    verify.add_argument('--edited-pdf', type=Path, required=True)
    verify.add_argument('--original-pdf', type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == 'prepare':
            print(prepare(args.source, args.out))
        else:
            print(json.dumps(check(args.edited_pdf, args.original_pdf), indent=2, ensure_ascii=False))
    except Exception as exc:
        print(f'edit_probe: {exc}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
