"""Create publication crops and the comparative proofs from the reviewed vector pages."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import csv,json,shutil
import numpy as np
import pymupdf as pdf
from build import FIGURES,ROOT,OUT,WORK,compute

def paper_and_reference():
    cropdir=OUT/'Paper_PDF';cropdir.mkdir(exist_ok=True)
    comparison=pdf.open()
    original=ROOT/'注意力增强：扩散生成语义引导.zip'
    with ZipFile(original) as supplied,pdf.open(OUT/'Diffusion_Methods_Native.pdf') as master:
        refs=[n for n in supplied.namelist() if n.endswith('.png') and not n.startswith('__MACOSX')]
        for i,page in enumerate(master):
            # Only use the preview for measuring white margins. Retain the PDF content stream.
            px=page.get_pixmap(matrix=pdf.Matrix(2.0,2.0),alpha=False)
            rgb=np.frombuffer(px.samples,dtype='uint8').reshape(px.height,px.width,px.n)
            content=(rgb[:,:,:3].min(axis=2)<238).any(axis=1).nonzero()[0]
            y0=max(0,float(content[0])/2-2.2);y1=min(page.rect.height,float(content[-1]+1)/2+2.2)
            part=pdf.open();part.insert_pdf(master,from_page=i,to_page=i)
            part[0].set_cropbox(pdf.Rect(0,y0,page.rect.width,y1))
            filename=f'{i+1:02d}_{FIGURES[i][0]}.pdf'
            part.save(cropdir/filename,garbage=4,deflate=True);part.close()
            with pdf.open(cropdir/filename) as check:
                assert not check[0].get_images(full=True) and check[0].get_text().strip()
            # The original left-hand image is for proofreading only. The right side uses the actual PDF streams.
            w=page.rect.width;h=page.rect.height;g=15;top=30
            canvas=comparison.new_page(width=w*2+3*g,height=h+top+g)
            left=pdf.Rect(g,top,g+w,top+h);right=pdf.Rect(2*g+w,top,2*g+w*2,top+h)
            canvas.insert_text((g,19),f'{i+1:02d}   {FIGURES[i][0]}  |  Supplied reference',fontsize=10,fontname='hebo',color=(.16,.21,.27))
            canvas.insert_text((right.x0,19),'Editable PowerPoint export',fontsize=10,fontname='hebo',color=(.16,.21,.27))
            canvas.insert_image(left,stream=supplied.read(refs[i]),keep_proportion=True)
            canvas.show_pdf_page(right,master,i)
            canvas.draw_line((w+1.5*g,top-3),(w+1.5*g,top+h),color=(.82,.85,.88),width=.65)
    comparison.save(OUT/'Original_vs_Redraw.pdf',garbage=4,deflate=True);comparison.close()

def bundle():
    supplement=OUT/'Reference_Layout/02_ControlNet_supplied_layout.pptx'
    assert supplement.is_file()
    evidence=json.loads((OUT/'Edit_Probe.json').read_text())
    assert evidence['changed_pixels']['outside_allowed_regions']==0
    files=['Diffusion_Methods_Native.pptx','Diffusion_Methods_Native.pdf','Original_vs_Redraw.pdf','使用说明.md',
           'Proofcheck.csv','Formula_Aspect_Ratios.csv','Edit_Probe.json']
    files += [str(f.relative_to(OUT)) for folder in ['Single_Figure_PPTX','Single_Figure_PDF','Paper_PDF','Reference_Layout'] for f in sorted((OUT/folder).iterdir()) if f.is_file()]
    target=OUT/'Diffusion_Methods_Native_Package.zip'
    with ZipFile(target,'w',compression=ZIP_DEFLATED,compresslevel=4) as z:
        for f in files:z.write(OUT/f,f)
        for src in sorted(Path(__file__).with_name('generated_sources').iterdir()):
            z.write(src,'Source_Artwork/'+src.name)
    with ZipFile(target) as zipped:
        assert zipped.testzip() is None
        assert len([n for n in zipped.namelist() if n.startswith('Paper_PDF/')])==8
        assert len([n for n in zipped.namelist() if n.startswith('Single_Figure_PPTX/')])==8
    print(target,target.stat().st_size)
if __name__=='__main__':
    compute();paper_and_reference();bundle()
