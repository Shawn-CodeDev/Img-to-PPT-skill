"""Translate smooth traced artwork to editable DrawingML, preserving painter's order and natural proportions."""
from functools import lru_cache
from pathlib import Path
import math,re
from zipfile import ZipFile
from io import BytesIO
from lxml import etree as ET
from PIL import Image,ImageOps
from fontTools.pens.recordingPen import RecordingPen
from fontTools.svgLib.path import parse_path
import vtracer
from canvas import em

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
CACHE=ROOT/'docs/public_results/.native_redraw_work/art-cubic-v2'
GENERATED=HERE/'generated_sources'
SHEETS={'fox':(4,2),'corgi':(4,2),'portrait':(3,2),'anime':(3,2),'stills':(3,2)}
SCENES={'mountains':2,'apples':3,'oranges':4,'catdog':5}
# Reference coordinates exclude the original film edges, lettering and frames.
REFERENCE={
  ('lake',0):(1,(65,148,178,228)),('lake',1):(1,(1155,214,1267,306)),
  ('edge',0):(1,(66,447,177,531)),('mask',0):(2,(224,600,304,671)),
  ('heatcat',0):(7,(569,230,645,307)),('heatdog',0):(7,(569,362,645,439)),
  ('noise',10):(7,(30,450,93,514)),('noise',11):(7,(957,325,1009,379)),
  ('noise',0):(0,(69,169,138,215)),('noise',1):(0,(155,169,225,215)),('noise',2):(0,(241,169,309,215))}
A='http://schemas.openxmlformats.org/drawingml/2006/main'
P='http://schemas.openxmlformats.org/presentationml/2006/main'
@lru_cache(maxsize=6)
def sheet(name):return Image.open(GENERATED/(name+'.png')).convert('RGB')
@lru_cache(maxsize=4)
def reference(i):
    with ZipFile(ROOT/'注意力增强：扩散生成语义引导.zip') as z:
        files=[n for n in z.namelist() if n.lower().endswith('.png') and not n.startswith('__MACOSX')]
        return Image.open(BytesIO(z.read(files[i]))).convert('RGB')
def source(kind,variant):
    if kind=='mask':
        import cv2
        import numpy as np
        cv2.setNumThreads(1)
        fruit=np.asarray(source('apples',0)).astype('int16')
        red,green,blue=fruit.transpose(2,0,1)
        mask=((red-green>27)&(red-blue>27)&(green<red*.78)).astype('uint8')*255
        mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(9,9)))
        contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        mask[:]=0
        cv2.drawContours(mask,[max(contours,key=cv2.contourArea)],-1,255,cv2.FILLED)
        return Image.fromarray(mask).convert('RGB')
    if (kind,variant) in REFERENCE:
        i,coords=REFERENCE[kind,variant];im=reference(i);sx,sy=im.width/1300,im.height/743
        return im.crop(tuple(round(v*(sx if j%2==0 else sy)) for j,v in enumerate(coords)))
    name=kind;index=variant
    if kind=='castle':name,index='stills',variant
    elif kind in SCENES:name,index='stills',SCENES[kind]
    elif kind=='fox':index=variant%4 if variant<10 else 4+variant-10
    cols,rows=SHEETS[name];im=sheet(name)
    x,y=index%cols,index//cols
    return im.crop((round(x*im.width/cols)+2,round(y*im.height/rows)+2,
                    round((x+1)*im.width/cols)-2,round((y+1)*im.height/rows)-2))

def geometry(chunk,sw,sh):
    pen=RecordingPen();parse_path(chunk.get('d'),pen)
    cmds=pen.value
    dx,dy=(float(v) for v in re.findall(r'[-.\d]+',chunk.get('transform','translate(0,0)')))
    # PowerPoint groups have no artboard clip. Clamp paths to the viewBox used in the SVG.
    cmds=[(cmd,[(min(sw,max(0,x+dx)),min(sh,max(0,y+dy))) for x,y in ps]) for cmd,ps in cmds]
    points=[(int(round(x*100)),int(round(y*100))) for _,ps in cmds for x,y in ps]
    xs,ys=zip(*points);left,right=min(xs),max(xs);top,bottom=min(ys),max(ys)
    w=max(1,right-left);h=max(1,bottom-top);parts=[]
    tags={'moveTo':'moveTo','lineTo':'lnTo','curveTo':'cubicBezTo','qCurveTo':'quadBezTo','closePath':'close'}
    for cmd,pts in cmds:
        tag=tags[cmd]
        if not pts:parts.append('<a:close/>');continue
        v=''.join(f'<a:pt x="{round(x*100)-left}" y="{round(y*100)-top}"/>' for x,y in pts)
        parts.append(f'<a:{tag}>{v}</a:{tag}>')
    return left,top,w,h,''.join(parts)

def noise_layers(variant,w,h):
    # Each palette layer has many small contours. These form the deliberately granular latent field.
    im=ImageOps.fit(source('noise',variant),(w,h),method=Image.Resampling.NEAREST).quantize(colors=48,dither=Image.Dither.NONE)
    palette=im.getpalette()
    regions=[[] for _ in range(48)]
    for index,c in enumerate(im.getdata()):
        x=(index%w)*100;y=(index//w)*100
        x1=min(w*100,x+111);y1=min(h*100,y+111)
        regions[c].append(f'<a:moveTo><a:pt x="{x}" y="{y}"/></a:moveTo><a:lnTo><a:pt x="{x1}" y="{y}"/></a:lnTo><a:lnTo><a:pt x="{x1}" y="{y1}"/></a:lnTo><a:lnTo><a:pt x="{x}" y="{y1}"/></a:lnTo><a:close/>')
    shapes=[]
    for i,parts in enumerate(regions):
        if not parts:continue
        color=''.join(f'{v:02X}' for v in palette[i*3:i*3+3])
        shapes.append(f'<p:sp><p:nvSpPr><p:cNvPr id="0" name="Latent field colour {color}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm>{xfrm(0,0,w*100,h*100)}</a:xfrm><a:custGeom><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/><a:rect l="l" t="t" r="r" b="b"/><a:pathLst><a:path w="{w*100}" h="{h*100}" stroke="0">{"".join(parts)}</a:path></a:pathLst></a:custGeom><a:solidFill><a:srgbClr val="{color}"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>')
    return ''.join(shapes)

def xfrm(x,y,w,h):
    return f'<a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/>'

@lru_cache(maxsize=85)
def prepare(kind,variant,w,h):
    CACHE.mkdir(parents=True,exist_ok=True)
    base=CACHE/f'{kind}-{variant}-{w}x{h}'
    if kind=='noise':return noise_layers(variant,w,h)
    if kind=='mask':base=base.with_name(base.name+'-fruit')
    vector=base.with_suffix('.svg')
    if not vector.exists():
        im=source(kind,variant)
        img=ImageOps.fit(im,(w,h),method=Image.Resampling.LANCZOS,centering=(.50,.40))
        png=base.with_suffix('.png');img.save(png)
        noise=kind=='noise'
        vtracer.convert_image_to_svg_py(str(png),str(vector),colormode='color',hierarchical='stacked',mode='spline',
                    filter_speckle=1 if noise else 3,color_precision=8,layer_difference=9 if noise else 6,
                    corner_threshold=55,length_threshold=3.5,max_iterations=10,splice_threshold=48,path_precision=2)
    shapes=[]
    for index,path in enumerate(ET.parse(vector).getroot().iter('{http://www.w3.org/2000/svg}path'),1):
        x,y,cx,cy,curve=geometry(path,w,h);color=path.get('fill')[1:]
        shapes.append(f'<p:sp><p:nvSpPr><p:cNvPr id="0" name="{kind} • colour region {index} • {color}"/>'
                      f'<p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm>{xfrm(x,y,cx,cy)}</a:xfrm>'
                      '<a:custGeom><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/><a:rect l="l" t="t" r="r" b="b"/>'
                      f'<a:pathLst><a:path w="{cx}" h="{cy}" stroke="0">{curve}</a:path></a:pathLst></a:custGeom>'
                      f'<a:solidFill><a:srgbClr val="{color}"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>')
    return ''.join(shapes)
def place(g,x,y,w,h,kind,variant):
    key=kind+'-'+str(variant)
    # Match panel aspect ratios by cropping the source proportionally before fitting curves.
    oversample=.92 if kind=='noise' else 1.80
    sw,sh=max(27,round(w*oversample)),max(27,round(h*oversample))
    xml=prepare(kind,variant,sw,sh)
    body=f'<p:grpSp xmlns:p="{P}" xmlns:a="{A}"><p:nvGrpSpPr><p:cNvPr id="0" name="{kind} • editable colour regions"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm>{xfrm(em(x),em(y),em(w),em(h))}<a:chOff x="0" y="0"/><a:chExt cx="{sw*100}" cy="{sh*100}"/></a:xfrm></p:grpSpPr>{xml}</p:grpSp>'
    tree=ET.fromstring(body.encode())
    for node in tree.iter('{'+P+'}cNvPr'):node.set('id',str(g.shapes._next_shape_id))
    g.shapes._spTree.insert_element_before(tree,'p:extLst')
