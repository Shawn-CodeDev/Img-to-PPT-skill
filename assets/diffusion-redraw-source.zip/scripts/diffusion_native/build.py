"""Build the native redraw and eight standalone figures from their shared drawing definitions."""
import json, os, socket, sys
from pathlib import Path
from pptx import Presentation
from pptx.util import Pt
from canvas import Canvas,WIDTH,HEIGHT,em
from pages_a import draw1,draw2,draw3
from pages_b import draw4,draw5,draw6
from pages_c import draw7,draw8

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'docs/public_results/diffusion_native_redraw'
WORK=ROOT/'docs/public_results/.native_redraw_work'
FIGURES=[('AnimateDiff',draw1),('ControlNet',draw2),('DiffEdit',draw3),('DreamBooth',draw4),
         ('PhotoMaker',draw5),('StoryDiffusion',draw6),('Diffusion-DPO',draw7),('Attend-and-Excite',draw8)]
def compute():
    if not os.environ.get('SLURM_JOB_ID') or any(k in socket.gethostname().lower() for k in ['login','head']):
        raise RuntimeError('Run on an allocated compute node')
def new():
    ppt=Presentation();ppt.slide_width=em(WIDTH);ppt.slide_height=em(HEIGHT)
    ppt.core_properties.title='Diffusion methods — editable vector redraws'
    return ppt
def draw(ppt,i):
    method,func=FIGURES[i];slide=ppt.slides.add_slide(ppt.slide_layouts[6])
    g=Canvas(slide);g.page=i+1;func(g)
    ids=[n.get('id') for n in slide._element.xpath('.//p:cNvPr')]
    if len(ids)!=len(set(ids)):raise ValueError(f'{method} contains duplicate PowerPoint object IDs')
    caveat={2:' The lower branch and its injections follow the authors’ ControlNet implementation (encoder, middle block, residuals into middle/skip activations).',3:' The illustrative mask isolates the fruit, and the inversion trajectory connects to the preserved region.',7:' The forward denoising prediction and parameter update are shown separately.',8:' The refined latent connects to continued sampling.'}.get(i+1,'')
    slide.notes_slide.notes_text_frame.text=f'{method}. Editable redraw of supplied schematic {i+1}. Animal, portrait, story, landscape and still-life samples are illustrative ImageGen assets vectorized for this diagram. They do not report experimental outputs. Source fonts were estimated visually from a flattened image.'+caveat
    return dict(figure=method,labels=g.labels,equations=g.formulas)
if __name__=='__main__':
    compute();WORK.mkdir(parents=True,exist_ok=True);OUT.mkdir(parents=True,exist_ok=True);singles=OUT/'Single_Figure_PPTX';singles.mkdir(exist_ok=True)
    deck=new();report=[]
    for i,(name,_) in enumerate(FIGURES):
        report.append(draw(deck,i))
        leaf=new();draw(leaf,i);leaf.save(singles/f'{i+1:02d}_{name}.pptx')
        print(i+1,name,len(report[-1]['labels']),'text boxes;',len(report[-1]['equations']),'Office Math objects',flush=True)
    deck.save(OUT/'Diffusion_Methods_Native.pptx')
    (WORK/'elements.json').write_text(json.dumps(report,indent=1,ensure_ascii=False))
