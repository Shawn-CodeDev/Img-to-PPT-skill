"""Illustrations drawn directly as editable PowerPoint curves, ellipses and rectangles."""
import random
from canvas import ArtCanvas
from vector_art import place

def simple(c,kind,variant):
    if kind=='paper':
        c.path('M10 3 H68 L91 25 V95 Q91 98 88 98 H10 Q7 98 7 94 V7 Q7 3 10 3 Z','#FBFCFE','#6B8097',2.8,name='Document body')
        c.path('M68 4 V25 H90',None,'#6B8097',2.6,name='Folded corner')
        for i,y in enumerate((39,56,73)):c.line(23,y,76 if i!=2 else 63,y,'#445360',2.6,f'Document line {i+1}')
    elif kind=='people':
        for i,(cx,cy,scale,k) in enumerate([(19,20,.78,'#9BB2B4'),(80,20,.78,'#97ABAC'),(50,18,.90,'#637E81')]):
            c.ellipse(cx-12*scale,cy-11*scale,24*scale,24*scale,k,name='Annotator head '+str(i+1))
            c.path(f'M{cx-13*scale} {cy+16*scale} Q{cx} {cy+10*scale} {cx+13*scale} {cy+16*scale} '
                   f'Q{cx+18*scale} {cy+17*scale} {cx+18*scale} {cy+29*scale} L{cx+16*scale} {cy+53*scale} '
                   f'L{cx+10*scale} {cy+53*scale} L{cx+8*scale} {cy+78*scale} H{cx-8*scale} '
                   f'L{cx-10*scale} {cy+53*scale} H{cx-16*scale} L{cx-18*scale} {cy+28*scale} Q{cx-18*scale} {cy+19*scale} {cx-13*scale} {cy+16*scale} Z',k,name='Annotator body '+str(i+1))
    elif kind=='grid':
        rng=random.Random(56+variant);shades=['#B4C8E9','#D4E0F2','#ACC2E4','#8AA9D4','#9EBBE1']
        for j in range(4):
            for k in range(3):c.rect(k*100/3,j*25,100/3,25,rng.choice(shades),'#9EB3D2',.6,name=f'Shared token {j+1},{k+1}')
        c.rect(0,0,100,100,None,'#5B76A0',1.6,name='Token grid boundary')

def paint(g,x,y,w,h,kind,variant,frame,name):
    with g.group(name):
        if frame in ('film','filmstrip'):
            g.rect(x,y,w,h,'#171B23',name='Film frame')
            b=max(1.8,min(4,w*.035));band=max(4,min(12,h*.13))
            ax,ay,aw,ah=x+b,y+band,w-2*b,h-2*band
            holes=max(4,round(w/(band*1.8)))
            for i in range(holes):
                for yp in (y+band*.23,y+h-band*.77):
                    g.rect(x+(i+.5)*w/holes-band*.24,yp,band*.48,band*.49,'#FBFCFE',name=f'Film perforation {i+1}')
        else:ax,ay,aw,ah=x,y,w,h
        c=ArtCanvas(g,ax,ay,aw,ah)
        if frame=='filmstrip':
            for i,pose in enumerate((0,0,2,4,5)):
                place(g,ax+i*aw/5,ay,aw/5-.8,ah,'anime',pose)
        elif kind not in ('paper','people','grid'):
            if kind=='noise' and frame=='none':variant=11 if 'Refined' in name else 10
            place(g,ax,ay,aw,ah,kind,variant)
        elif kind in ('paper','people','grid'):simple(c,kind,variant)
        else:raise ValueError(kind)
        if frame=='line' or kind in ('heatcat','heatdog','catdog','mask') or (kind=='noise' and frame=='none'):
            g.rect(x,y,w,h,None,'#35444C' if kind!='mask' else '#84A94C',1.25,name='Illustration boundary')
