"""Measure the intrinsic equation boxes using the same Office Math importer as the PDF proof."""
from pathlib import Path
from lxml import etree as ET
from collections import Counter
import json,re,sys
import pymupdf
from pptx.enum.text import PP_ALIGN
from pptx.util import Pt
from build import new,compute,FIGURES,WORK
from equations import math_run
from canvas import Canvas,PPT_PT

base=WORK/'math-calibration'
manifest=base.with_suffix('.json')
dims=Path(__file__).with_name('formula_metrics.json')
def prepare():
    # The text definitions are shared with the delivered slides. Artwork has no equations.
    pres=new()
    terms=set()
    for method,draw in FIGURES:
        g=Canvas(pres.slides.add_slide(pres.slide_layouts[6]))
        g.art=lambda *args,**kwargs:None
        draw(g)
        terms.update(row[-1] for row in g.formulas)
    probe=new()
    for tex in sorted(terms):
        g=Canvas(probe.slides.add_slide(probe.slide_layouts[6]))
        s=g._textbox(25,25,240,50,'Formula scale specimen')
        p=s.text_frame.paragraphs[0]
        p.alignment=PP_ALIGN.CENTER
        p.font.name='Cambria Math'
        p.font.size=Pt(20*PPT_PT)
        p._p.append(math_run(tex,20*PPT_PT))
    probe.save(base.with_suffix('.pptx'))
    manifest.write_text(json.dumps(sorted(terms),ensure_ascii=False))

def measure():
    values={}
    with pymupdf.open(base.with_suffix('.pdf')) as pdf:
        for page,tex in zip(pdf,json.loads(manifest.read_text()),strict=True):
            svg=ET.fromstring(page.get_svg_image(text_as_path=False).encode())
            sizes=[];letters=[]
            for text in svg.xpath('//*[local-name()="text"]'):
                if not ''.join(text.itertext()).strip():continue
                tr=text.get('transform','matrix(1 0 0 1 0 0)')
                m=[float(s) for s in re.findall(r'[-.\d]+(?:e[-+]?\d+)?',tr)]
                size=float(text.get('font-size'))
                value=(size*abs(m[0]),size*abs(m[3]));sizes.append(value)
                t=''.join(text.itertext()).strip()
                if any(v.isalpha() or v.isdigit() for v in t):
                    letters.append(value)
            if not sizes:raise ValueError(tex)
            # The largest font is the main line; nested scripts have smaller ems.
            sx,sy=max(letters or sizes,key=lambda p:p[0]*p[1])
            values[tex]=[round(240*PPT_PT/sx,4),round(50*PPT_PT/sy,4)]
    dims.write_text(json.dumps(values,indent=1,ensure_ascii=False)+'\n')
    print(len(values),'calibrated native formulas')
if __name__=='__main__':
    compute()
    (prepare if sys.argv[1]=='prepare' else measure)()
