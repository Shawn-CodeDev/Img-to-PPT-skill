#!/usr/bin/env python3
"""Audit an eight-figure native PowerPoint/PDF delivery and split its PDF pages.

Usage: python proofcheck.py /path/to/diffusion_native_redraw

The audit compares each combined-deck slide with its corresponding one-slide deck,
checks native editable text and Office Math, rejects picture/hidden elements,
checks PDF geometry/fonts/text, writes Single_Figure_PDF/*.pdf, and emits
Proofcheck.csv with one row per figure plus an aggregate row.
"""
from __future__ import annotations

import argparse
import csv
import math
import re
import sys
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

import pymupdf as fitz

P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
NS = {"p": P_NS, "a": A_NS, "m": M_NS}
EXPECTED_RATIO = 1300 / 743
RATIO_TOLERANCE = 0.0015


def _tag(ns: str, local: str) -> str:
    return f"{{{ns}}}{local}"


def _parts(zip_path: Path) -> list[str]:
    with zipfile.ZipFile(zip_path) as zf:
        names = zf.namelist()
    return sorted(
        (n for n in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
        key=lambda n: int(re.search(r"slide(\d+)", n).group(1)),
    )


def _presentation_size(zip_path: Path) -> tuple[int, int]:
    with zipfile.ZipFile(zip_path) as zf:
        root = ET.fromstring(zf.read("ppt/presentation.xml"))
    size = root.find("p:sldSz", NS)
    if size is None:
        raise ValueError(f"No slide size in {zip_path}")
    return int(size.attrib["cx"]), int(size.attrib["cy"])


def _hidden_nodes(root: ET.Element) -> int:
    count = 0
    for element in root.iter():
        for key, value in element.attrib.items():
            local = key.rsplit("}", 1)[-1].lower()
            if local in {"hidden", "show"} and value.strip().lower() in {"1", "true", "0", "false"}:
                # p:sldId show="1" and cNvPr hidden="0" are explicit visible values.
                if value.strip().lower() in {"0", "false"} and local == "show":
                    count += 1
                elif value.strip().lower() in {"1", "true"} and local == "hidden":
                    count += 1
    count += sum(
        1 for e in root.iter(_tag(A_NS, "alpha"))
        if e.attrib.get("val", "100000").strip() in {"0", "0.0"}
    )
    return count


def _slide_audit(xml: bytes) -> dict[str, Any]:
    root = ET.fromstring(xml)
    object_ids=[n.get("id") for n in root.iter(_tag(P_NS, "cNvPr"))]
    if len(object_ids)!=len(set(object_ids)):
        raise ValueError("Slide contains duplicate object IDs")
    shape_nodes = sum(1 for node in root.iter() if node.tag in {
        _tag(P_NS, "sp"), _tag(P_NS, "cxnSp"), _tag(P_NS, "pic"), _tag(P_NS, "graphicFrame"),
    })
    groups = sum(1 for _ in root.iter(_tag(P_NS, "grpSp")))
    pictures = sum(1 for _ in root.iter(_tag(P_NS, "pic")))
    blips = sum(1 for _ in root.iter(_tag(A_NS, "blip")))
    editable_shapes = []
    body_text: list[str] = []
    for shape in root.iter(_tag(P_NS, "sp")):
        tx_body = shape.find("p:txBody", NS)
        if tx_body is None:
            continue
        text = "".join((node.text or "") for node in tx_body.iter(_tag(A_NS, "t")))
        if text:
            editable_shapes.append(text)
            body_text.append(text)
    formula_text = [
        "".join((node.text or "") for node in math.iter(_tag(M_NS, "t")))
        for math in root.iter(_tag(M_NS, "oMath"))
    ]
    formula_text = [text for text in formula_text if text]
    return {
        "shape_count": shape_nodes,
        "group_count": groups,
        "bezier_count": sum(1 for _ in root.iter(_tag(A_NS, "cubicBezTo")))
                         + sum(1 for _ in root.iter(_tag(A_NS, "quadBezTo"))),
        "text_box_count": len(editable_shapes),
        "editable_text_chars": sum(len(x) for x in editable_shapes),
        "omml_count": len(formula_text),
        "image_count": pictures + blips,
        "hidden_count": _hidden_nodes(root),
        "body_text": body_text,
        "formula_text": formula_text,
    }


def _deck_audit(path: Path) -> dict[str, Any]:
    with zipfile.ZipFile(path) as zf:
        slide_parts = _parts(path)
        slides = [_slide_audit(zf.read(part)) for part in slide_parts]
        media = [n for n in zf.namelist() if n.startswith("ppt/media/") and not n.endswith("/")]
        presentation = ET.fromstring(zf.read("ppt/presentation.xml"))
        hidden_slides = sum(
            1 for sid in presentation.iter(_tag(P_NS, "sldId"))
            if sid.attrib.get("show", "1").strip().lower() in {"0", "false"}
        )
    width, height = _presentation_size(path)
    return {
        "slides": slides,
        "media_count": len(media),
        "hidden_slide_count": hidden_slides,
        "slide_width_emu": width,
        "slide_height_emu": height,
        "slide_ratio": width / height,
    }


def _pdf_page_audit(doc: fitz.Document, index: int) -> dict[str, Any]:
    page = doc[index]
    rect = page.rect
    fonts: dict[int, tuple[str, bool]] = {}
    for font in page.get_fonts(full=True):
        xref = int(font[0])
        name = str(font[3] if len(font) > 3 else f"xref-{xref}")
        if xref in fonts:
            continue
        embedded = False
        if xref > 0:
            try:
                extracted = doc.extract_font(xref)
                embedded = bool(extracted and len(extracted) >= 4 and extracted[3])
            except Exception:
                embedded = False
        fonts[xref] = (name, embedded)
    text = page.get_text("text") or ""
    invisible_text = 0
    try:
        invisible_text = sum(1 for span in page.get_texttrace() if span.get("type") == 3 or span.get("opacity", 1) <= 0)
    except Exception:
        pass
    invisible_drawings = 0
    try:
        for drawing in page.get_drawings():
            fill = drawing.get("fill_opacity")
            stroke = drawing.get("stroke_opacity")
            if (fill is None or fill <= 0) and (stroke is None or stroke <= 0):
                invisible_drawings += 1
    except Exception:
        pass
    ocgs = doc.get_ocgs() or {}
    hidden_ocgs = sum(1 for value in ocgs.values() if not value.get("on", True))
    font_names = sorted({name for name, _ in fonts.values()})
    embedded_count = sum(1 for _, embedded in fonts.values() if embedded)
    return {
        "pdf_width_pt": round(rect.width, 3),
        "pdf_height_pt": round(rect.height, 3),
        "pdf_ratio": rect.width / rect.height,
        "pdf_image_count": len(page.get_images(full=True)),
        "pdf_font_count": len(fonts),
        "pdf_fonts_embedded_count": embedded_count,
        "pdf_fonts_embedded": bool(fonts) and embedded_count == len(fonts),
        "pdf_font_names": "; ".join(font_names),
        "pdf_bad_glyph_count": text.count("¿") + text.count("�"),
        "pdf_hidden_count": invisible_text + invisible_drawings + hidden_ocgs,
        "pdf_text_chars": len(text),
        "pdf_ocg_count": len(ocgs),
    }


def _single_files(folder: Path) -> list[tuple[int, Path]]:
    found: list[tuple[int, Path]] = []
    for path in folder.glob("*.pptx"):
        match = re.match(r"^(\d{2})_(.+)$", path.stem)
        if match:
            found.append((int(match.group(1)), path))
    return sorted(found)


def _split_pdf(pdf_path: Path, single_ppts: list[tuple[int, Path]], out_dir: Path) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    outputs: list[Path] = []
    with fitz.open(pdf_path) as source:
        for index, (_, single_ppt) in enumerate(single_ppts):
            if index >= source.page_count:
                break
            output = fitz.open()
            output.insert_pdf(source, from_page=index, to_page=index)
            destination = out_dir / f"{single_ppt.stem}.pdf"
            temporary = destination.with_name(destination.stem + ".tmp.pdf")
            output.save(temporary, garbage=4, deflate=True)
            output.close()
            temporary.replace(destination)
            outputs.append(destination)
    return outputs


def _ratio_match(ratio: float) -> bool:
    return math.isfinite(ratio) and abs(ratio - EXPECTED_RATIO) <= RATIO_TOLERANCE


def audit(root: Path) -> tuple[list[dict[str, Any]], bool]:
    root = root.resolve()
    combined_pptx = root / "Diffusion_Methods_Native.pptx"
    combined_pdf = root / "Diffusion_Methods_Native.pdf"
    single_dir = root / "Single_Figure_PPTX"
    single_files = _single_files(single_dir)
    if not combined_pptx.is_file() or not combined_pdf.is_file():
        raise FileNotFoundError("Expected Diffusion_Methods_Native.pptx and .pdf in root directory")
    if len(single_files) != 8 or [number for number, _ in single_files] != list(range(1, 9)):
        raise ValueError(f"Expected eight numbered single PPTX files in {single_dir}; found {len(single_files)}")

    master = _deck_audit(combined_pptx)
    if len(master["slides"]) != 8:
        raise ValueError(f"Expected 8 combined PPTX slides, found {len(master['slides'])}")
    singles = [_deck_audit(path) for _, path in single_files]
    split_paths = _split_pdf(combined_pdf, single_files, root / "Single_Figure_PDF")
    with fitz.open(combined_pdf) as pdf:
        pdf_pages = [_pdf_page_audit(pdf, i) for i in range(pdf.page_count)]
        pdf_page_count = pdf.page_count
    split_pages: list[dict[str, Any] | None] = []
    for path in split_paths:
        with fitz.open(path) as split_doc:
            split_pages.append(_pdf_page_audit(split_doc, 0) if split_doc.page_count == 1 else None)

    rows: list[dict[str, Any]] = []
    all_pass = pdf_page_count == 8 and abs(master["slide_ratio"] - EXPECTED_RATIO) <= 1e-6
    for i in range(8):
        slide = master["slides"][i]
        single_deck = singles[i]
        single_slide = single_deck["slides"][0] if len(single_deck["slides"]) == 1 else None
        page_pdf = pdf_pages[i] if i < pdf_page_count else None
        single_pdf = split_paths[i] if i < len(split_paths) else None
        split_pdf = split_pages[i] if i < len(split_pages) else None
        same_contents = bool(single_slide) and slide["body_text"] == single_slide["body_text"] and slide["formula_text"] == single_slide["formula_text"]
        same_objects = bool(single_slide) and all(
            slide[key] == single_slide[key]
            for key in ("shape_count", "group_count", "bezier_count", "text_box_count", "omml_count")
        )
        single_ratio_ok = abs(single_deck["slide_ratio"] - master["slide_ratio"]) <= 1e-9
        ppt_clean = (
            slide["image_count"] == 0 and master["media_count"] == 0
            and slide["hidden_count"] == 0 and master["hidden_slide_count"] == 0
            and slide["text_box_count"] > 0 and slide["editable_text_chars"] > 0 and slide["omml_count"] > 0
        )
        single_clean = bool(single_slide) and (
            single_slide["image_count"] == 0 and single_deck["media_count"] == 0
            and single_slide["hidden_count"] == 0 and single_deck["hidden_slide_count"] == 0
            and single_slide["text_box_count"] > 0 and single_slide["editable_text_chars"] > 0
        )
        pdf_ok = bool(page_pdf) and (
            page_pdf["pdf_image_count"] == 0 and page_pdf["pdf_hidden_count"] == 0
            and page_pdf["pdf_fonts_embedded"] and page_pdf["pdf_bad_glyph_count"] == 0
            and _ratio_match(page_pdf["pdf_ratio"])
        )
        split_pdf_ok = bool(split_pdf) and (
            split_pdf["pdf_image_count"] == 0 and split_pdf["pdf_hidden_count"] == 0
            and split_pdf["pdf_fonts_embedded"] and split_pdf["pdf_bad_glyph_count"] == 0
            and _ratio_match(split_pdf["pdf_ratio"])
            and page_pdf is not None and abs(split_pdf["pdf_ratio"] - page_pdf["pdf_ratio"]) <= 1e-9
        )
        row_pass = bool(single_slide) and same_contents and same_objects and single_ratio_ok and ppt_clean and single_clean and pdf_ok and split_pdf_ok and single_pdf is not None
        all_pass = all_pass and row_pass
        row: dict[str, Any] = {
            "page": i + 1,
            "figure": single_files[i][1].stem,
            "combined_slides": len(master["slides"]),
            "single_slides": len(single_deck["slides"]),
            "shape_count": slide["shape_count"],
            "group_count": slide["group_count"],
            "bezier_count": slide["bezier_count"],
            "text_box_count": slide["text_box_count"],
            "editable_text_chars": slide["editable_text_chars"],
            "omml_count": slide["omml_count"],
            "image_count": slide["image_count"],
            "ppt_media_count": master["media_count"] if i == 0 else 0,
            "ppt_hidden_count": slide["hidden_count"] + (master["hidden_slide_count"] if i == 0 else 0),
            "single_shape_count": single_slide["shape_count"] if single_slide else 0,
            "single_group_count": single_slide["group_count"] if single_slide else 0,
            "single_bezier_count": single_slide["bezier_count"] if single_slide else 0,
            "single_text_box_count": single_slide["text_box_count"] if single_slide else 0,
            "single_omml_count": single_slide["omml_count"] if single_slide else 0,
            "single_media_count": single_deck["media_count"],
            "body_formula_match": same_contents,
            "object_counts_match": same_objects,
            "combined_canvas_ratio": round(master["slide_ratio"], 8),
            "single_canvas_ratio": round(single_deck["slide_ratio"], 8),
            "pdf_width_pt": page_pdf["pdf_width_pt"] if page_pdf else "",
            "pdf_height_pt": page_pdf["pdf_height_pt"] if page_pdf else "",
            "pdf_ratio": round(page_pdf["pdf_ratio"], 8) if page_pdf else "",
            "pdf_image_count": page_pdf["pdf_image_count"] if page_pdf else "",
            "pdf_hidden_count": page_pdf["pdf_hidden_count"] if page_pdf else "",
            "pdf_font_count": page_pdf["pdf_font_count"] if page_pdf else "",
            "pdf_embedded_font_count": page_pdf["pdf_fonts_embedded_count"] if page_pdf else "",
            "pdf_fonts_embedded": page_pdf["pdf_fonts_embedded"] if page_pdf else False,
            "pdf_font_names": page_pdf["pdf_font_names"] if page_pdf else "",
            "pdf_bad_glyph_count": page_pdf["pdf_bad_glyph_count"] if page_pdf else "",
            "pdf_text_chars": page_pdf["pdf_text_chars"] if page_pdf else "",
            "split_pdf_page_count": 1 if split_pdf else 0,
            "split_pdf_ratio": round(split_pdf["pdf_ratio"], 8) if split_pdf else "",
            "split_pdf_image_count": split_pdf["pdf_image_count"] if split_pdf else "",
            "split_pdf_hidden_count": split_pdf["pdf_hidden_count"] if split_pdf else "",
            "split_pdf_fonts_embedded": split_pdf["pdf_fonts_embedded"] if split_pdf else False,
            "split_pdf": str(single_pdf.relative_to(root)) if single_pdf else "",
            "status": "PASS" if row_pass else "FAIL",
        }
        rows.append(row)

    totals: dict[str, Any] = {"page": "TOTAL", "figure": "All figures"}
    sum_fields = {
        "single_slides", "shape_count", "group_count", "bezier_count",
        "text_box_count", "editable_text_chars", "omml_count", "image_count", "ppt_media_count", "ppt_hidden_count",
        "single_shape_count", "single_group_count", "single_bezier_count", "single_text_box_count",
        "single_omml_count", "single_media_count", "pdf_image_count", "pdf_hidden_count",
        "pdf_bad_glyph_count", "pdf_text_chars",
        "split_pdf_page_count", "split_pdf_image_count", "split_pdf_hidden_count",
    }
    for field in sum_fields:
        totals[field] = sum(float(row.get(field) or 0) for row in rows)
        if totals[field].is_integer():
            totals[field] = int(totals[field])
    fonts={name for row in rows for name in row["pdf_font_names"].split("; ") if name}
    totals.update({
        "combined_slides":len(master["slides"]),
        "pdf_width_pt":rows[0]["pdf_width_pt"],
        "pdf_height_pt":rows[0]["pdf_height_pt"],
        "pdf_font_count":len(fonts),
        "pdf_embedded_font_count":len(fonts) if all(row["pdf_fonts_embedded"] for row in rows) else "",
        "body_formula_match": all(bool(row["body_formula_match"]) for row in rows),
        "object_counts_match": all(bool(row["object_counts_match"]) for row in rows),
        "combined_canvas_ratio": round(master["slide_ratio"], 8),
        "single_canvas_ratio": round(master["slide_ratio"], 8),
        "pdf_ratio": round(EXPECTED_RATIO, 8),
        "pdf_fonts_embedded": all(bool(row["pdf_fonts_embedded"]) for row in rows),
        "split_pdf_fonts_embedded": all(bool(row["split_pdf_fonts_embedded"]) for row in rows),
        "pdf_font_names": "; ".join(sorted({name for row in rows for name in str(row["pdf_font_names"]).split("; ") if name})),
        "split_pdf": "Single_Figure_PDF/*.pdf",
        "status": "PASS" if all_pass else "FAIL",
    })
    rows.append(totals)

    csv_path = root / "Proofcheck.csv"
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    return rows, all_pass


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root_dir", type=Path, help="Final diffusion_native_redraw directory")
    args = parser.parse_args()
    try:
        rows, passed = audit(args.root_dir)
    except Exception as exc:
        print(f"proofcheck: {exc}", file=sys.stderr)
        return 2
    total = rows[-1]
    print(
        f"proofcheck: {total['status']} — 8 figures, {total['shape_count']} shapes, "
        f"{total['text_box_count']} editable text boxes, {total['omml_count']} OMML objects; "
        f"CSV: {args.root_dir / 'Proofcheck.csv'}; PDFs: {args.root_dir / 'Single_Figure_PDF'}"
    )
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
