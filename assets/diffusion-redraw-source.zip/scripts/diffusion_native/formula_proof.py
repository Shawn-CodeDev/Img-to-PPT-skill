"""Measure type geometry from the final PDF itself and check each native equation against its printed glyphs."""
from pathlib import Path
import csv,json,math,re
from lxml import etree as ET
import pymupdf
from build import OUT,WORK,compute

def numbers(t):
    return [float(n) for n in re.findall(r'[-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?',t)]
def verify():
    report=json.loads((WORK/'elements.json').read_text())
    rows=[]
    with pymupdf.open(OUT/'Diffusion_Methods_Native.pdf') as doc:
        for no,page in enumerate(doc):
            scale=page.rect.width/1300
            # Resolve text transforms directly from the PDF interpretation. Translation alone
            # never changes glyph aspect ratio. The control values are orthogonal axes in points.
            svg=ET.fromstring(page.get_svg_image(text_as_path=False).encode())
            runs=[]
            for t in svg.xpath('//*[local-name()="text"]'):
                a,b,c,d,e,f=numbers(t.get('transform','matrix(1 0 0 1 0 0)'))
                scale_x=math.hypot(a,b);scale_y=abs(a*d-b*c)/scale_x  # exclude deliberate italic shear
                for span in t.xpath('.//*[local-name()="tspan"]'):
                    val=''.join(span.itertext()).strip()
                    if not val or not span.get('x') or not span.get('y'):continue
                    x=numbers(span.get('x'))[0];y=numbers(span.get('y'))[0]
                    xx=(a*x+c*y+e)/scale;yy=(b*x+d*y+f)/scale
                    runs.append((xx,yy,val,scale_x/scale_y,float(t.get('font-size'))))
            for name,x,y,w,h,tex in report[no]['equations']:
                nearby=[r for r in runs if x-1.5<=r[0]<=x+w+1.5 and y-1.5<=r[1]<=y+h+1.5]
                if not nearby:raise ValueError((no+1,tex,'no visible glyphs in equation bounds'))
                # Delimiter variants (absolute bars, parentheses) may intentionally grow around a
                # tall argument. Measure letters, numbers and operators independently from delimiters.
                normal=[r for r in nearby if any(k.isalnum() or k in 'εθ←>⊕∼⊙∇*=' for k in r[2])]
                if not normal:normal=nearby
                delta=max(abs(r[3]-1) for r in normal)
                rows.append([no+1,name,tex,len(nearby),round(min(r[3] for r in normal),4),round(max(r[3] for r in normal),4),round(delta*100,2)])
    with (OUT/'Formula_Aspect_Ratios.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['page','editable_object','formula_latex','printed_glyph_runs','min_horizontal_over_vertical','max_horizontal_over_vertical','max_deviation_percent']);w.writerows(rows)
    print('Equation boxes checked:',len(rows),'worst deviation (%):',max(r[-1] for r in rows))
    bad=[r for r in rows if r[-1]>3]
    for row in bad:print('OUTLIER',row)
    if bad:raise ValueError('Nonuniform equation scaling exceeds 3 percent')
if __name__=='__main__':compute();verify()
