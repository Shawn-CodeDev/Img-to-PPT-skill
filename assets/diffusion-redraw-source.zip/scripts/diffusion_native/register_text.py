"""Conservatively register native text boxes to ink measured in the source figures.

`--build-reference PATH` is the offline OpenCV step. Run it once on a single
Slurm CPU to create a small metadata-only JSON. Normal rendering only reads that
JSON; it never opens source images or performs image processing.
"""
from __future__ import annotations

import argparse
import json
import math
import re
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LABELS = ROOT / 'scripts/diffusion_facsimile/labels.json'
SOURCE_DIR = ROOT / 'docs/public_results/.ppt_reference_work'
DEFAULT_REFERENCE = Path(__file__).with_name('text_registration.json')
PAGE_WIDTH = 1300.0
PAGE_HEIGHT = 743.0
# These short strings are ambiguous throughout diagrams and are not worth fitting.
SHORT_WORDS = {
    'image', 'input', 'output', 'model', 'loss', 'encoder', 'decoder', 'middle',
    'denoising', 'condition', 'frozen', 'latent', 'video', 'text', 'prompt',
}
MATH_CHARS = set('$…⋯∼≈≠≤≥∑∫⊙⊗←→↔Δθεηλμσφψω𝒩ℒ₀₁₂₃₄₅₆₇₈₉ₜₛᵢᵣᵉᵈᵗᶜ')


def _key(text: str) -> str:
    return ' '.join(str(text).split())


def _eligible(text: str) -> bool:
    s = str(text)
    if not s.strip() or any(ch in MATH_CHARS for ch in s):
        return False
    if not any(ch.isalpha() for ch in s):
        return False
    words = re.findall(r'[A-Za-z]+', s)
    if len(words) == 1 and words[0].lower() in SHORT_WORDS:
        return False
    if len(s.strip()) < 8:
        return False
    return True


def build_reference(output: str | Path = DEFAULT_REFERENCE) -> dict:
    """Detect tight source ink boxes in source annotation ROIs and save metadata."""
    import cv2
    import numpy as np

    labels = json.loads(LABELS.read_text(encoding='utf-8'))
    records: dict[str, list[dict]] = {}
    for page in range(1, 9):
        image_path = SOURCE_DIR / f'{page}.jpg'
        bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
        if bgr is None:
            continue
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        height, width = gray.shape
        scale = width / PAGE_WIDTH
        page_records = []
        for idx, item in enumerate(labels.get(str(page), [])):
            x0, y0, x1, y1, text, style = item
            if not _eligible(text):
                continue
            # Expand slightly so imperfect label boxes still capture glyph overshoots.
            pad_x = max(5, round((x1-x0)*.035))
            pad_y = max(4, round((y1-y0)*.12))
            xa, ya = max(0, round((x0-pad_x)*scale)), max(0, round((y0-pad_y)*scale))
            xb, yb = min(width, round((x1+pad_x)*scale)), min(height, round((y1+pad_y)*scale))
            roi = gray[ya:yb, xa:xb]
            if roi.size == 0:
                continue
            # Retain dark ink, including antialiased edges; bright diagram fills are excluded.
            dark = (roi < 176).astype('uint8')
            n, labs, stats, centroids = cv2.connectedComponentsWithStats(dark, connectivity=8)
            candidates = []
            bx0, by0, bx1, by1 = (x0*scale, y0*scale, x1*scale, y1*scale)
            box_w, box_h = max(1, bx1-bx0), max(1, by1-by0)
            for comp in range(1, n):
                rx, ry, rw, rh, area = map(int, stats[comp])
                gx, gy = xa+rx, ya+ry
                cx, cy = centroids[comp][0]+xa, centroids[comp][1]+ya
                if area < 2 or area > max(500, box_w*box_h*.18):
                    continue
                # Exclude connector strokes, dotted panel boundaries and large glyph-like art.
                if rh < 3 or rh > max(24, box_h*1.25):
                    continue
                if rw > max(28, box_w*.42) or rw > 8.0*rh:
                    continue
                if rh <= 3 and rw >= max(5, box_w*.025):
                    continue
                if not (bx0-2 <= cx <= bx1+2 and by0-2 <= cy <= by1+2):
                    continue
                candidates.append((gx, gy, gx+rw, gy+rh, area))
            if len(candidates) < 3:
                continue
            # Group glyph components into text lines by their vertical ink rows.
            row_mask = np.zeros((yb-ya, xb-xa), dtype='uint8')
            for ax, ay, ar, ab, _ in candidates:
                row_mask[ay-ya:ab-ya, ax-xa:ar-xa] = 1
            row_ids = np.flatnonzero(row_mask.any(axis=1)) + ya
            if not len(row_ids):
                continue
            groups = []
            start = prev = int(row_ids[0])
            for yy in row_ids[1:]:
                yy = int(yy)
                if yy-prev > 3:
                    groups.append((start, prev+1))
                    start = yy
                prev = yy
            groups.append((start, prev+1))
            # Merge closely separated rows (e.g. punctuation/diacritics) into lines.
            merged = []
            for a, b in groups:
                if merged and a-merged[-1][1] <= max(3, round(box_h*.12)):
                    merged[-1] = (merged[-1][0], b)
                else:
                    merged.append((a, b))
            # Source line spacing is larger than the short antialias gaps within glyphs.
            line_groups = []
            for a, b in merged:
                if line_groups and a-line_groups[-1][1] < max(5, round(box_h*.23)):
                    line_groups[-1] = (line_groups[-1][0], b)
                else:
                    line_groups.append((a, b))
            ink_x0 = min(c[0] for c in candidates)
            ink_y0 = min(c[1] for c in candidates)
            ink_x1 = max(c[2] for c in candidates)
            ink_y1 = max(c[3] for c in candidates)
            line_heights = [b-a for a, b in line_groups]
            # Reject detections that barely cover the expected annotation region.
            expected_lines = max(1, len(str(text).splitlines()))
            if (ink_x1-ink_x0) < max(7, box_w*.12) or (ink_y1-ink_y0) < max(5, box_h*.25):
                continue
            if expected_lines > 1 and len(line_groups) > expected_lines+1:
                continue
            if abs(len(line_groups)-expected_lines) > 1:
                # The ROI likely contains nearby non-text lines or neighboring labels.
                continue
            density = min(1.0, len(candidates) / max(4, len(re.sub(r'\s', '', text))*.45))
            # Penalize detections dominated by one anomalously large component.
            largest = max(c[4] for c in candidates)
            quality = max(0.0, min(1.0, .55 + .35*density - .25*largest/max(1, sum(c[4] for c in candidates))))
            if quality < .48:
                continue
            page_records.append({
                'index': idx,
                'text': text,
                'key': _key(text),
                'style': style,
                'label_box': [round(x0,2), round(y0,2), round(x1,2), round(y1,2)],
                'ink_box': [round(ink_x0/scale,2), round(ink_y0/scale,2), round(ink_x1/scale,2), round(ink_y1/scale,2)],
                'center': [round((ink_x0+ink_x1)/(2*scale),2), round((ink_y0+ink_y1)/(2*scale),2)],
                'ink_width': round((ink_x1-ink_x0)/scale,2),
                'ink_height': round((ink_y1-ink_y0)/scale,2),
                'line_height': round(float(np.median(line_heights))/scale,2),
                'line_count': len(line_groups),
                'confidence': round(quality,3),
            })
        records[str(page)] = page_records
    payload = {
        'schema': 1,
        'coordinate_width': int(PAGE_WIDTH),
        'coordinate_height': int(PAGE_HEIGHT),
        'source': 'docs/public_results/.ppt_reference_work/{page}.jpg',
        'records': records,
    }
    out = Path(output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=1)+'\n', encoding='utf-8')
    return payload


@lru_cache(maxsize=2)
def _load(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding='utf-8')).get('records', {})
    except (OSError, ValueError, TypeError):
        return {}


@lru_cache(maxsize=256)
def _font_metrics(path: str, text: str) -> tuple[float, float]:
    """Return text width and ink-height per font pixel using the active NATIVE_FONTS."""
    try:
        from PIL import ImageFont
        p = Path(path)
        f = ImageFont.truetype(str(p), 160)
        width = max((f.getlength(line) for line in text.splitlines()), default=1.0)/160
        heights = []
        for line in text.splitlines():
            box = f.getbbox(line)
            heights.append(max(1, box[3]-box[1])/160)
        return width, (sum(heights)/max(1,len(heights)))
    except (OSError, ValueError, ImportError):
        # Conservative Times/Arial approximations when a caller only needs geometry.
        return max(.35, len(text)*.53), .76


def _font_file(font: str, bold: bool, italic: bool) -> str:
    import os
    family = 'Sans' if font in ('Arial', 'Liberation Sans', 'Aptos', 'Calibri') else 'Serif'
    face = ('Bold' if bold else '') + ('Italic' if italic else '') or 'Regular'
    root = Path(os.environ.get('NATIVE_FONTS', '/usr/share/fonts/truetype/liberation'))
    return str(root / f'Liberation{family}-{face}.ttf')


def fit_text(page, x, y, w, h, txt, size, font='Times New Roman', bold=False, italic=False, align='center'):
    """Fit one plain native-text box to a trusted source ink registration.

    Returns ``(x, y, w, h, size)`` in the same reference-pixel coordinates.
    A missing, ambiguous, distant, or low-confidence match returns the inputs.
    ``align`` remains the caller's alignment; left-aligned text stays left-aligned.
    """
    fallback = (x, y, w, h, size)
    if not _eligible(txt):
        return fallback
    page = str(page)
    rows = _load(str(DEFAULT_REFERENCE)).get(page, [])
    key = _key(txt)
    candidates = [r for r in rows if r.get('key') == key and r.get('confidence', 0) >= .58]
    if not candidates:
        return fallback
    anchor_x = x if align == 'left' else x+w if align == 'right' else x+w/2
    anchor_y = y+h/2
    # Exact text + nearest source position resolves repeated words without global guessing.
    best = min(candidates, key=lambda r: math.hypot(r['center'][0]-anchor_x, r['center'][1]-anchor_y))
    dist = math.hypot(best['center'][0]-anchor_x, best['center'][1]-anchor_y)
    limit = min(90.0, max(38.0, .42*math.hypot(w, h)))
    if dist > limit:
        return fallback
    ix0, iy0, ix1, iy1 = best['ink_box']
    ink_w, ink_h = max(1.0, ix1-ix0), max(1.0, iy1-iy0)
    line_h = max(1.0, best.get('line_height') or ink_h)
    line_count = max(1, int(best.get('line_count') or len(str(txt).splitlines())))
    ratio_w, ratio_h = _font_metrics(_font_file(font, bold, italic), str(txt))
    # Match observed glyph height without forcing glyphs to stretch to the observed width.
    desired_size = min(line_h/max(.35, ratio_h), (ink_w+2)/max(.1,ratio_w)*1.035)
    size_new = min(float(size)*1.18, max(float(size)*.78, desired_size))
    natural_w = ratio_w*size_new
    pad_x = min(9.0, max(3.0, .22*line_h))
    width_new = max(ink_w+2*pad_x, natural_w+2*pad_x)
    width_new = min(width_new, max(w*.62, min(w*1.12, PAGE_WIDTH)))
    pad_y = min(8.0, max(3.0, .20*line_h))
    height_new = max(ink_h+2*pad_y, size_new*(.92+1.09*(line_count-1))+2*pad_y)
    height_new = min(height_new, max(h*.72, h*1.18))
    if align == 'left':
        x_new = ix0-pad_x
    elif align == 'right':
        x_new = ix1+pad_x-width_new
    else:
        center_x = (ix0+ix1)/2
        x_new = center_x-width_new/2
    center_y = (iy0+iy1)/2
    y_new = center_y-height_new/2
    # Keep boxes on canvas and retain a readable minimum font size.
    width_new = min(max(8.0, width_new), PAGE_WIDTH)
    height_new = min(max(8.0, height_new), PAGE_HEIGHT)
    x_new = min(max(0.0, x_new), PAGE_WIDTH-width_new)
    y_new = min(max(0.0, y_new), PAGE_HEIGHT-height_new)
    return tuple(round(v, 2) for v in (x_new, y_new, width_new, height_new, size_new))


def _self_check() -> int:
    """Print compact caption checks after the reference JSON has been built."""
    examples = [
        (1, 396, 268, 508, 31, '(a) Learning Transferable Motion Priors', 28),
        (2, 458, 682, 385, 49, 'ControlNet Principle', 39),
        (3, 570, 698, 159, 34, 'DiffEdit', 34),
    ]
    failures = 0
    for page, x, y, w, h, txt, size in examples:
        result = fit_text(page, x, y, w, h, txt, size)
        moved = result != (x, y, w, h, size)
        if not moved:
            failures += 1
        print(json.dumps({'page': page, 'text': txt, 'input': [x,y,w,h,size],
                          'fit': result, 'matched': moved}, ensure_ascii=False))
    return failures


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--build-reference', nargs='?', const=str(DEFAULT_REFERENCE), metavar='JSON',
                        help='extract source ink metadata (run on a compute node)')
    parser.add_argument('--check', action='store_true', help='check three caption registrations')
    args = parser.parse_args()
    if args.build_reference:
        data = build_reference(args.build_reference)
        print(f"wrote {sum(map(len, data['records'].values()))} ink registrations to {args.build_reference}")
    if args.check:
        raise SystemExit(_self_check())
    if not args.build_reference and not args.check:
        parser.print_help()


if __name__ == '__main__':
    main()
